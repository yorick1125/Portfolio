To run the application open the exe file and make sure all 
these items are in the same folder.
Enjoy!