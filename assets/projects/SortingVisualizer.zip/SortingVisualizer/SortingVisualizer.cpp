
#include <iostream>
#include <conio.h>
#include <Windows.h>
#include <limits>
#include <sstream>
#include <stdlib.h>

using namespace std;

const int YPOS = 20;
const int XPOS = 20;


HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
COORD CursorPosition;

const int CONSOLE_WIDTH = 106;
const int CONSOLE_HEIGHT = 35;
const int CONSOLEMIDDLEX = CONSOLE_WIDTH / 2;
const int CONSOLEMIDDLEY = CONSOLE_HEIGHT / 2;

class Console
{
private:
	int Width;
	int Height;
	int middleX;
	int middleY;
public:
	Console()
	{
		// Settings
		HWND console = GetConsoleWindow();
		RECT ConsoleRect;
		GetWindowRect(console, &ConsoleRect);
		MoveWindow(console, ConsoleRect.left, ConsoleRect.top, ConsoleRect.right, ConsoleRect.bottom, TRUE);

		// Constructor
		Width = ConsoleRect.right;
		Height = ConsoleRect.bottom;
		middleX = Width / 2;
		middleY = Height / 2;

	}
	Console(int width, int height)
	{
		// Settings
		HWND console = GetConsoleWindow();
		RECT ConsoleRect;
		GetWindowRect(console, &ConsoleRect);
		MoveWindow(console, ConsoleRect.left, ConsoleRect.top, width, height, TRUE);

		// Constructor
		Width = width;
		Height = height;
		middleX = Width / 2;
		middleY = Height / 2;
	}
};

void goToXY(int x, int y)
{
	CursorPosition.X = x;
	CursorPosition.Y = y;
	SetConsoleCursorPosition(console, CursorPosition);
}

void SetCursorVisibility(bool isVisibile)
{
	HANDLE out = GetStdHandle(STD_OUTPUT_HANDLE);

	CONSOLE_CURSOR_INFO     cursorInfo;

	GetConsoleCursorInfo(out, &cursorInfo);
	cursorInfo.bVisible = isVisibile; // set the cursor visibility
	SetConsoleCursorInfo(out, &cursorInfo);
}



class Bar
{
public:
	int value;
	int x;
	int y;
	char icon;

	Bar()
	{
		value = 0;
		y = 0;
		x = 0;
		icon = '|';
	}

	Bar(int val, int xpos)
	{
		value = val;
		y = YPOS;
		x = xpos;
		icon = '|';
	}

	void Draw()
	{
		for (int i = 0; i < value; i++)
		{
			goToXY(x, y - i);
			cout << icon << endl;
		}
	}

	void Erase()
	{
		for (int i = 0; i < value; i++)
		{
			goToXY(x, y - i);
			cout << ' ' << endl;
		}
	}

	void MoveLeft()
	{
		x--;
		Draw();
	}

	void MoveRight()
	{
		x++;
		Draw();
	}
};

void Swap(int *a, int *b)
{
	int temp = *a;
	*a = *b;
	*b = temp;
}

void BubbleSort(Bar bars[], int noBars)
{
	int temp;
	for (int i = 0; i < noBars - 1; i++) // Current Number
	{
		goToXY(0, 1);
		cout << "Pass " << i + 1 << endl;
		for (int j = 0; j < noBars - 1; j++) // Previous Number
		{
			if (bars[j].value > bars[j + 1].value)
			{
				//Erase both
				bars[j].Erase();
				bars[j + 1].Erase();

				//Swap their places
				Swap(&bars[j].value, &bars[j + 1].value);

				//Redraw both
				bars[j].Draw();
				bars[j + 1].Draw();
				Sleep(100);
			}
		}
	}
}

void SelectionSort(Bar bars[], int noBars)
{
	int smallest;

	for (int i = 0; i < noBars - 1; i++)
	{
		smallest = i;
		for (int j = i + 1; j < noBars; j++)
		{
			if (bars[j].value < bars[smallest].value)
			{
				smallest = j;
			}

		}
		//Erase both
		bars[smallest].Erase();
		bars[i].Erase();

		//Swap
		Swap(&bars[smallest].value, &bars[i].value);

		//Redraw both
		bars[smallest].Draw();
		bars[i].Draw();
		Sleep(100);
	}
}

void InsertionSort(Bar bars[], int noBars)
{
	int temp;
	int j;

	for (int i = 0; i < noBars; i++)
	{
		j = i;
		while (j > 0 && bars[j].value < bars[j - 1].value)
		{
			// Erase
			bars[j].Erase();
			bars[j - 1].Erase();
			// Swap
			Swap(&bars[j].value, &bars[j - 1].value);
			// Draw
			bars[j].Draw();
			bars[j - 1].Draw();

			j--;
		}
	}

}

void ClearScreen()
{
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	int columns, rows;

	GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &csbi);
	columns = csbi.srWindow.Right - csbi.srWindow.Left + 1;
	rows = csbi.srWindow.Bottom - csbi.srWindow.Top + 1;

	for (int i = 0; i < rows; i++)
	{
		for (int j = 0; j < columns; j++)
		{
			cout << " ";
		}
		cout << endl;
	}

	char key = _getch();
	goToXY(0, 0);
}

int ValidateChoice()
{
	int choice;
	cin >> choice;
	while(cin.fail() || choice < 1 || choice > 3)
	{
		cin.clear();
		cin.ignore(1000, '\n');
		cout << "Please enter a valid choice. " << endl;
		cin >> choice;
	}

	return choice;

}

int ValidateSize()
{
	int size;
	cin >> size;
	while (cin.fail() || size > 25 || size < 1)
	{
		cin.clear();
		cin.ignore(1000, '\n');
		cout << "Please enter a size between 0 and 25. ";
		cin >> size;
	}

	return size;

}

void main()
{

	goToXY(0, 0);
	cout << "Welcome to the Sorting Algorithm visualizer" << endl;
	cout << "This program will represent an array of numbers as a graph where vertical bars will represent the height of each " << endl;
	cout << " integer in the arrayand visually represent how each sorting algorithm works.  " << endl;
	cout << "Please enter the number corresponding to one of the following options" << endl;
	cout << "[1] Bubble Sort" << endl;
	cout << "[2] Selection Sort" << endl;
	cout << "[3] Insertion Sort" << endl;

	
	int option = ValidateChoice();



	system("CLS");
	goToXY(0, 0);
	cout << "Please enter a number no bigger than 25 to be used as the size of the array. " << endl;

	int noBars = ValidateSize();
	system("CLS");

	SetCursorVisibility(false);


	int MaxRandNum = 15;
	Bar bars[25];

	for (int i = 0; i < noBars; i++)
	{
		bars[i] = Bar(rand() % MaxRandNum, XPOS + i + (i*3));
		bars[i].Draw();
	}

	char key = '.';
	while (true)
	{
		key = _getch();
		if (key == 'r')
		{
			for (int i = 0; i < noBars; i++)
			{
				bars[i].Erase();
				bars[i] = Bar(rand() % MaxRandNum + 2, XPOS + i);
				bars[i].Draw();
			}
		}
		if (key == ' ')
		{
			goToXY(0, 0);
			cout << "Sorting..." << endl;
			break;
		}
	}


	//BubbleSort
	if (option == 1)
	{
		BubbleSort(bars, noBars);
	}
	else if (option == 2)
	{
		SelectionSort(bars, noBars);
	}
	else if (option == 3)
	{
		InsertionSort(bars, noBars);
	}



	while (1)
	{
		goToXY(0, 0);
		cout << "Finished Sorting!" << endl;
		cout << "Press 'R' to go back to main menu. " << endl;
		cout << "To quit press 'q'." << endl;

		key = _getch();

		if (key == 'q')
		{
			break;
		}
		if (key == 'r')
		{
			system("CLS");
			main();
		}
	}

}


