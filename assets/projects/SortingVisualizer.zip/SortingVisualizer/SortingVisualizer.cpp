
#include <iostream>
#include <conio.h>
#include <Windows.h>

using namespace std;

const int YPOS = 20;
const int XPOS = 20;


HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
COORD CursorPosition;

const int CONSOLE_WIDTH = 106;
const int CONSOLE_HEIGHT = 35;
const int CONSOLEMIDDLEX = CONSOLE_WIDTH / 2;
const int CONSOLEMIDDLEY = CONSOLE_HEIGHT / 2;

class Console
{
private:
	int Width;
	int Height;
	int middleX;
	int middleY;
public:
	Console()
	{
		// Settings
		HWND console = GetConsoleWindow();
		RECT ConsoleRect;
		GetWindowRect(console, &ConsoleRect);
		MoveWindow(console, ConsoleRect.left, ConsoleRect.top, ConsoleRect.right, ConsoleRect.bottom, TRUE);

		// Constructor
		Width = ConsoleRect.right;
		Height = ConsoleRect.bottom;
		middleX = Width / 2;
		middleY = Height / 2;

	}
	Console(int width, int height)
	{
		// Settings
		HWND console = GetConsoleWindow();
		RECT ConsoleRect;
		GetWindowRect(console, &ConsoleRect);
		MoveWindow(console, ConsoleRect.left, ConsoleRect.top, width, height, TRUE);

		// Constructor
		Width = width;
		Height = height;
		middleX = Width / 2;
		middleY = Height / 2;
	}
};

void goToXY(int x, int y)
{
	CursorPosition.X = x;
	CursorPosition.Y = y;
	SetConsoleCursorPosition(console, CursorPosition);
}

void SetCursorVisibility(bool isVisibile)
{
	HANDLE out = GetStdHandle(STD_OUTPUT_HANDLE);

	CONSOLE_CURSOR_INFO     cursorInfo;

	GetConsoleCursorInfo(out, &cursorInfo);
	cursorInfo.bVisible = isVisibile; // set the cursor visibility
	SetConsoleCursorInfo(out, &cursorInfo);
}



class Bar
{
public:
	int value;
	int x;
	int y;
	char icon;

	Bar()
	{
		value = 0;
		y = 0;
		x = 0;
		icon = '|';
	}

	Bar(int val, int xpos)
	{
		value = val;
		y = YPOS;
		x = xpos;
		icon = '|';
	}

	void Draw()
	{
		for (int i = 0; i < value; i++)
		{
			goToXY(x, y - i);
			cout << icon << endl;
		}
	}

	void Erase()
	{
		for (int i = 0; i < value; i++)
		{
			goToXY(x, y - i);
			cout << ' ' << endl;
		}
	}

	void MoveLeft()
	{
		x--;
		Draw();
	}

	void MoveRight()
	{
		x++;
		Draw();
	}
};



void main()
{

	SetCursorVisibility(false);
	goToXY(0, 0);
	cout << "Welcome to the Sorting Algorithm visualizer" << endl;
	cout << "This program will represent an array of numbers as a graph where vertical bars will represent the height of each " << endl;
	cout << " integer in the arrayand visually represent how each sorting algorithm works.  " << endl;
	cout << "Please enter the number corresponding to one of the following options" << endl;
	cout << "[1] Bubble Sort" << endl;
	
	int option;
	cin >> option;

	goToXY(0, 0);
	cout << "                                                                                                          " << endl;
	cout << "                                                                                                                     " << endl;
	cout << "                                                                               " << endl;
	cout << "                                                                               " << endl;
	cout << "                                                                               " << endl;
	cout << "                                                                               " << endl;
	cout << "                                                                               " << endl;

	goToXY(0, 0);
	cout << "Please enter a number no bigger than 50 to be used as the size of the array. " << endl;

	int noBars;
	cin >> noBars;

	goToXY(0, 0);
	cout << "                                                                                   " << endl;
	goToXY(0, 3);
	cout << "                                                                                   " << endl;


	int MaxRandNum = 15;
	Bar bars[50];

	for (int i = 0; i < noBars; i++)
	{
		bars[i] = Bar(rand() % MaxRandNum, XPOS + i + (i*3));
		bars[i].Draw();
	}

	char key = '.';
	while (true)
	{
		key = _getch();
		if (key == 'r')
		{
			for (int i = 0; i < noBars; i++)
			{
				bars[i].Erase();
				bars[i] = Bar(rand() % MaxRandNum + 2, XPOS + i);
				bars[i].Draw();
			}
		}
		if (key == ' ')
		{
			goToXY(0, 0);
			cout << "Sorting..." << endl;
			break;
		}
	}


	//BubbleSort
	if (option == 1)
	{
		int temp;
		for (int i = 0; i < noBars - 1; i++) // Current Number
		{
			goToXY(0, 1);
			cout << "Pass " << i + 1 << endl;
			for (int j = 0; j < noBars - 1; j++) // Previous Number
			{
				if (bars[j].value < bars[j + 1].value)
				{
					//Erase both
					bars[j].Erase();
					bars[j + 1].Erase();

					//Swap their places
					temp = bars[j + 1].value;
					bars[j + 1].value = bars[j].value;
					bars[j].value = temp;

					//Redraw both
					bars[j].Draw();
					bars[j + 1].Draw();
					Sleep(100);
				}
			}
		}
	}



	while (1)
	{
		goToXY(0, 0);
		cout << "Finished Sorting!" << endl;
		cout << "Press 'R' to go back to main menu. " << endl;
		cout << "To quit press 'q'." << endl;

		key = _getch();

		if (key == 'q')
		{
			break;
		}
		if (key == 'r')
		{
			goToXY(0, 0);
			cout << "                                               " << endl;
			cout << "                                                                               " << endl;
			cout << "                                  " << endl;
			cout << "                                  " << endl;
			 
			main();
		}
	}

}


