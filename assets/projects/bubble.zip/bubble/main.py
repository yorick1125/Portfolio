import pygame
import time
import random
import math

# Initialize Pygame
pygame.init()

# Global Variables
windowWidth = 500
windowHeight = 500
middleX = windowWidth/2
middleY = windowHeight/2
gameWindow = pygame.display.set_mode((windowWidth, windowHeight))
font = pygame.font.SysFont("Arial", 40)
intro_string = "A simple game of chance where two \npeople pick a color, red or blue, to try and figure out which one will win. Try playing to understand better"
speed = 1
noBubbles = 10
rad = 10
bubbles = []
pygameimg = pygame.image.load('pygameimg.png')


class Bubble:
    def __init__(self, color):
        self.radius = rad
        self.velocityX = random.randint(2, 10)
        self.velocityY = random.randint(2, 10)
        self.minXPos = self.radius + self.velocityX
        self.minYPos = self.radius + self.velocityY
        self.maxXPos = windowWidth - self.radius - self.velocityX
        self.maxYPos = windowHeight - self.radius - self.velocityY
        self.x = random.randint(self.minXPos, self.maxXPos)
        self.y = random.randint(self.minYPos, self.maxYPos)
        self.color = color
        self.isAlive = True

    def check_bounds(self):
        outer_right = self.x >= self.maxXPos
        outer_left = self.x < self.minXPos
        outer_down = self.y > self.maxYPos
        outer_up = self.y < self.minYPos

        if outer_left or outer_right:
            self.velocityX = -self.velocityX
        if outer_down or outer_up:
            self.velocityY = -self.velocityY

    def move(self):
        self.x += self.velocityX
        self.y += self.velocityY

    def calculate_distance(self, bub):
        hypotenuse = math.hypot(self.x - bub.x, self.y - bub.y)
        return hypotenuse

    def is_colliding(self, bub):
        distance = self.calculate_distance(bub)
        return 0 < distance <= (self.radius + bub.radius)

    def check_bubble_collision(self, bubbles_list):
        for other in bubbles_list:
            if self.is_colliding(other):
                if self.radius >= other.radius:
                    other.isAlive = False
                    bubbles.remove(other)
                    self.radius += 5
                elif other.radius >= self.radius:
                    self.isAlive = False
                    bubbles.remove(self)
                    other.radius += 5


# Functions
def initialize_bubbles():

    for i in range(noBubbles):
        if i < noBubbles/2:
            bubbles.append(Bubble((255, 0, 0)))
        else:
            bubbles.append(Bubble((0, 0, 255)))


def random_color():
    r = random.randint(0, 1)
    # red
    if r == 0:
        return 255, 0, 0
    # blue
    if r == 1:
        return 0, 0, 255


def draw_start_game(text, font, color, x, y,):
    # drawing text
    textobj = font.render(text, 1, color)
    textrect = textobj.get_rect()
    textrect.topleft = (x, y)
    gameWindow.blit(textobj, textrect)
    # if text was clicked
    mouse_pos = pygame.mouse.get_pos()
    for event in pygame.event.get():
        if textrect.collidepoint(mouse_pos) and event.type == pygame.MOUSEBUTTONDOWN:
            game()


def draw_text(text, font, color, x, y):
    # drawing text
    textobj = font.render(text, 1, color)
    textrect = textobj.get_rect()
    textrect.topleft = (x, y)
    gameWindow.blit(textobj, textrect)


def only_one_bubble_remaining():
    # Check if only one bubble is remaining
    no_bubbles_alive = 0
    for bubble in bubbles:
        if bubble.isAlive:
            no_bubbles_alive += 1

    if no_bubbles_alive == 1:
        return True
    else:
        return False


def only_two_bubbles_remaining():
    # Check if only two bubbles are remaining
    no_bubbles_alive = 0
    for bubble in bubbles:
        if bubble.isAlive:
            no_bubbles_alive += 1

    if no_bubbles_alive == 2:
        return True
    else:
        return False


def only_one_color_remaining():
    # Check if all remaining bubbles are the same
    previous_color = bubbles[0].color
    for bubble in bubbles:
        if bubble.color != previous_color:
            return False
        previous_color = bubble.color

    return True


# Game Methods
def main_menu():
    pygame.display.set_caption("Main Menu")
    exit_game = False
    while not exit_game:
        gameWindow.fill((0, 0, 0))
        draw_start_game('Start Game', font, (255, 255, 255), middleX - 70, 60)
        gameWindow.blit(pygameimg, (middleX - 60, middleY - 120))
        # draw_text('Welcome to Bubble Guess game created by Yorick Niyonkuru', (pygame.font.SysFont("Arial", 20)), (255, 255, 255), 30, middleY + 50)
        # draw_text('Choose either red or blue and see which one wins.', (pygame.font.SysFont("Arial", 20)), (255, 255, 255), 70, middleY + 80)
        # draw_text('Click Start Game to start', (pygame.font.SysFont("Arial", 20)), (255, 255, 255), middleX - 90, middleY + 110)
        pygame.display.update()
        # Checking through game events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                exit_game = True
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                exit_game = True
                pygame.quit()
                exit()


def game():
    # Set up game
    pygame.display.set_caption("Bubble Guess")
    initialize_bubbles()
    quitGame = False

    while not quitGame:
        pygame.time.delay(30)

        # Checking through game events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quitGame = True
                pygame.quit()
                exit()

        five_seconds_passed = False
        # if only two bubbles left and five seconds passed start a countdown
        # if only_two_bubbles_remaining() and five_seconds_passed:



        # Check win status
        if only_one_bubble_remaining() or only_one_color_remaining():
            win()

        # Bubble Movement
        gameWindow.fill((0, 0, 0))
        for bubble in bubbles:
            if bubble.isAlive:
                # Check Collision with other Bubbles
                bubble.check_bubble_collision(bubbles)
                # Move
                bubble.check_bounds()
                bubble.move()
                # Draw
                pygame.draw.circle(gameWindow, bubble.color, (bubble.x, bubble.y), bubble.radius)
                pygame.display.update()


def win():
    pygame.display.set_caption("End Game")
    gameWindow.fill((0, 0, 0))
    exit_game = False

    for bubble in bubbles:
        if bubble.isAlive:
            winning_color = bubble.color
            break

    while not exit_game:
        # Checking through game events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                exit_game = True
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                # reset all bubbles radiuses
                for bubble in bubbles:
                    bubble.radius = rad
                game()

        if winning_color == (255, 0, 0):
            draw_text('Red Has Won!', font, (255, 0, 0), middleX - 100, 60)
        elif winning_color == (0, 0, 255):
            draw_text('Blue Has Won!', font, (0, 0, 255), middleX - 100, 60)

        draw_text('Press any key to play again', font, (255, 255, 255), 60, 120)
        pygame.display.update()



# Game Program
main_menu()




