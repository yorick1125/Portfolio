This app was not in any way supposed to be a professional game. 
This was just my way of learning python by trying 
to apply the physics of moving bubbles to an actual screen I
could see visually. Also gave me time to practice debugging skills 
using Pycharm.

To use the program:
1- Python must be installed on your computer
2- open command prompt and change to the directory the file is currently in
3- make sure the img is in the same file
4- type 'python main.py' into the console

Made by Yorick Niyonkuru.
