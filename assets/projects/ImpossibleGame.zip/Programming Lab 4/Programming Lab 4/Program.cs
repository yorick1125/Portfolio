﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;


namespace gametester
{
    public class Mob
    {
        public static int xpos, ypos, count = 0;
        public static string icon = "0", deletemob = " ";
        public static bool alive = true;
        public static bool bulletc = false;
        public static DateTime previousmobmove = DateTime.Now;
        public static TimeSpan mobmoveinterval = new TimeSpan(0, 0, 0, 0, 500);
        public static Mob[] totalmobs = new Mob[100];
    }

    class Bullet
    {
        //Bullets
        public static int xpos, ypos;
        public static string bulletchar = "*";
        public static List<int> bulletsx = new List<int>();
        public static List<int> bulletsy = new List<int>();


    }

    class Program
    {
        //Constants
        public const int buffersize_x = 120;
        public const int buffersize_y = 30;
        public const int windowsize_x = 120;
        public const int windowsize_y = 30;
        public const int windowcenter_x = windowsize_x / 2;
        public const int windowcenter_y = windowsize_y / 2;
        public const int screenmin = 0;
        public const int statliney = 5;

        //Global variables

        //Player
        public static int playerx = windowcenter_x;
        public static int playery;
        public static string deletep = " ";


        //Food
        public static int foodx;
        public static int foody;

        //Stats
        public static int gamespeed, score, health;
        public static int statsx = 0;
        public static int statsy = 4;

        //Other
        public static string playerchar = " X ", foodchar = "@";
        public static ConsoleKeyInfo keyInfo;
        public static bool gameover = false;
        public static Random rnd = new Random();
        public static int interval = 5;

        public static void Main()
        {
            //Variables
            playery = windowcenter_y;//15



            //Settings();
            //display size and cursor position at the beginning
            Console.SetWindowSize(windowsize_x, windowsize_y);
            Console.SetBufferSize(buffersize_x, buffersize_y);
            Console.SetCursorPosition(windowcenter_x, windowcenter_y);
            Console.CursorVisible = false;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write(playerchar);
            Console.ForegroundColor = ConsoleColor.White;
            gamespeed = 1;
            health = 100;
            score = 0;

            //Spawn Objects
            SpawnFood();
            SpawnMob();


            while (!gameover)
            {
                Stats();
                MovePlayer();//player mouvement with keyboard
                Movemob();
               
            }

            Console.ReadKey();
        }//end of main

        public static void Menu()
        {
            Console.SetCursorPosition(windowcenter_x, 2);
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine(@"

██╗   ██╗ ██████╗ ██████╗ ██╗ ██████╗██╗  ██╗
╚██╗ ██╔╝██╔═══██╗██╔══██╗██║██╔════╝██║ ██╔╝
 ╚████╔╝ ██║   ██║██████╔╝██║██║     █████╔╝ 
  ╚██╔╝  ██║   ██║██╔══██╗██║██║     ██╔═██╗ 
   ██║   ╚██████╔╝██║  ██║██║╚██████╗██║  ██╗
   ╚═╝    ╚═════╝ ╚═╝  ╚═╝╚═╝ ╚═════╝╚═╝  ╚═╝
         
");
            Console.ForegroundColor = ConsoleColor.White;

        }

        public static void Settings()
        {
            //display size and cursor position at the beginning
            Console.SetWindowSize(windowsize_x, windowsize_y);
            Console.SetBufferSize(buffersize_x, buffersize_y);
            Console.SetCursorPosition(windowcenter_x, windowcenter_y);
            Console.CursorVisible = false;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write(playerchar);
            Console.ForegroundColor = ConsoleColor.White;
            gamespeed = 1;
            health = 100;
            score = 0;
        }

        public static void SpawnMob()
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            Mob mob = new Mob();
            //spawn in random location
            Mob.xpos = rnd.Next(1, windowsize_x);
            Mob.ypos = rnd.Next(statliney + 1, windowsize_y);
            Console.SetCursorPosition(Mob.xpos, Mob.ypos);
            Console.Write(Mob.icon);
            Mob.count++;

            Console.ForegroundColor = ConsoleColor.White;
        }

        public static void SpawnFood()
        {
            Console.ForegroundColor = ConsoleColor.Green;

            //spawn in random location
            foodx = rnd.Next(1, windowsize_x);
            foody = rnd.Next(statliney + 1, windowsize_y);
            Console.SetCursorPosition(foodx, foody);
            Console.Write(foodchar);

            Console.ForegroundColor = ConsoleColor.White;
        }

        public static void MovePlayer()
        {
            if ((Console.KeyAvailable))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                keyInfo = Console.ReadKey(true);
                string direction = "up";
                switch (keyInfo.Key)
                {
                    //Mouvement

                    //Up
                    case ConsoleKey.W:
                        Console.SetCursorPosition(playerx + 1, playery);
                        Console.Write(" ");//Erases previous player character
                        direction = "up";
                        playery -= gamespeed;
                        OffScreenP();//Preventing player from going off the screen
                        break;
                    //Down
                    case ConsoleKey.S:
                        Console.SetCursorPosition(playerx + 1, playery);
                        Console.Write(" ");//Erases previous player character
                        direction = "down";
                        playery += gamespeed;
                        OffScreenP();//Preventing player from going off the screen
                        break;
                    //Left
                    case ConsoleKey.A:
                        Console.SetCursorPosition(playerx, playery);
                        Console.Write(" ");//Erases previous player character
                        direction = "left";
                        playerx -= gamespeed;
                        OffScreenP();//Preventing player from going off the screen
                        break;
                    //Right
                    case ConsoleKey.D:
                        Console.SetCursorPosition(playerx, playery);
                        Console.Write(" ");//Erases previous player character
                        direction = "right";
                        playerx += gamespeed;
                        OffScreenP();//Preventing player from going off the screen
                        break;


                    //Shoot
                    case ConsoleKey.Spacebar:
                        ShootBullet(ref direction);
                        break;

                    //Changing Gamespeed during gameplay

                    case ConsoleKey.D1:
                        gamespeed = 1;
                        break;
                    case ConsoleKey.D2:
                        gamespeed = 2;
                        break;
                    case ConsoleKey.D3:
                        gamespeed = 3;
                        break;
                    case ConsoleKey.D4:
                        gamespeed = 4;
                        break;
                    case ConsoleKey.D5:
                        gamespeed = 5;
                        break;

                }//end of switch

                Console.SetCursorPosition(playerx, playery);//Sets to the new position
                Console.Write(playerchar);//Draw PLayer



                if (playerx == foodx && playery == foody)//player eats food
                {
                    SpawnFood();//whenever player eats food a new one spawns
                    health += 30;
                    if (health > 100)
                    {
                        health = 100;
                    }
                }
                if (keyInfo.Key == ConsoleKey.Escape)
                {
                    PauseMenu();
                    Console.SetCursorPosition(playerx, playery);
                    Console.Write(playerchar);
                    Console.SetCursorPosition(playerx, playery);
                }
            }//end of Console.ReadKey if statement
        }

        public static void Movemob()
        {
            Console.ForegroundColor = ConsoleColor.Blue;

            int direction;
            bool bulletc = BulletCollision();
            if (bulletc == true)
            {
                Console.SetCursorPosition(Mob.xpos, Mob.ypos);
                Console.Write(Mob.deletemob);//Deletes mob
                score += 100;
                for (int i = 0; i < Mob.count; i++)
                {
                    SpawnMob();
                }
            }

            if ((DateTime.Now - Mob.previousmobmove) >= Mob.mobmoveinterval && Mob.alive == true)
            {
                for (int i = 0; i < Mob.count; i++)
                {
                    if (bulletc == false)
                    {
                        Mob.previousmobmove = DateTime.Now;
                        direction = rnd.Next(1, 4);
                        switch (direction)
                        {

                            //Mouvement

                            case 1://Up
                                Console.SetCursorPosition(Mob.xpos, Mob.ypos);
                                Mob.ypos -= 1;
                                //Preventing mob from going off the screen
                                OffScreenM();
                                Console.Write(Mob.deletemob);
                                Console.SetCursorPosition(Mob.xpos, Mob.ypos);
                                break;

                            case 2://Down
                                Console.SetCursorPosition(Mob.xpos, Mob.ypos);
                                Mob.ypos += 1;
                                //Preventing mob from going off the screen
                                OffScreenM();
                                Console.Write(Mob.deletemob);
                                Console.SetCursorPosition(Mob.xpos, Mob.ypos);
                                break;

                            case 3://Left
                                Console.SetCursorPosition(Mob.xpos, Mob.ypos);
                                Mob.xpos -= 1;
                                //Preventing mob from going off the screen
                                OffScreenM();
                                Console.Write(Mob.deletemob);
                                Console.SetCursorPosition(Mob.xpos, Mob.ypos);
                                break;

                            case 4://Right
                                Console.SetCursorPosition(Mob.xpos, Mob.ypos);
                                Mob.xpos += 1;
                                //Preventing mob from going off the screen
                                OffScreenM();
                                Console.Write(Mob.deletemob);
                                Console.SetCursorPosition(Mob.xpos, Mob.ypos);
                                break;
                        }
                        //Draw
                        Console.Write(Mob.icon);

                    }
                }
            }

            else if (Mob.alive == false)
            {
                for (int i = 0; i < Mob.count; i++)
                {
                    SpawnMob();
                }
            }
            Console.ForegroundColor = ConsoleColor.White;

        }

        public static void ShootBullet(ref string direction)
        {
            Bullet.bulletsx.Add(playerx);
            Bullet.bulletsy.Add(playery);



            Console.SetCursorPosition(Bullet.xpos, Bullet.ypos);
            Console.Write(" ");

            if (direction == "up")
            {
                Bullet.ypos -= 1;
            }
            if (direction == "down")
            {
                Bullet.ypos += 1;
            }
            if (direction == "left")
            {
                Bullet.xpos -= 1;
            }
            if (direction == "right")
            {
                Bullet.xpos += 1;
            }

            Console.SetCursorPosition(Bullet.xpos, Bullet.ypos);
            Console.Write(Bullet.bulletchar);
        }

        public static bool BulletCollision()
        {
            bool bulletc = false;

            if (Bullet.xpos == Mob.xpos && Bullet.ypos == Mob.ypos)
            {
                bulletc = true;
            }
            return bulletc;

        }

        public static void OffScreenP()
        {
            //Right
            if (playerx >= buffersize_x - 1)
            {
                playerx -= gamespeed;

            }
            //Left
            if (playerx < screenmin)
            {
                playerx += gamespeed;
            }
            //Down
            if (playery >= buffersize_y)
            {
                playery -= gamespeed;
            }
            //Up
            if (playery < statliney)
            {
                playery += gamespeed;
            }
        }

        public static void OffScreenM()
        {
            //Right
            if (Mob.xpos >= buffersize_x - 1)
            {
                Mob.xpos -= 2;

            }
            //Left
            if (Mob.xpos <= screenmin)
            {
                Mob.xpos += 2;
            }
            //Down
            if (Mob.ypos >= buffersize_y)
            {
                Mob.ypos -= 2;
            }
            //Up
            if (Mob.ypos < statliney)
            {
                Mob.ypos += 2;
            }

        }

        public static void Stats()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.SetCursorPosition(statsx, statsy);
            for (int i = 0; i < windowsize_x; i++)
            {
                Console.Write("_");
            }
            statsy -= 3;
            Console.SetCursorPosition(statsx, statsy);
            Console.WriteLine("Health: " + health);
            Console.WriteLine("Score: " + score);
            Console.WriteLine("Gamespeed: " + gamespeed);
            Console.ForegroundColor = ConsoleColor.White;
            statsy = 4;
            Console.SetCursorPosition(playerx, playery);

        }

        public static void PauseMenu()
        {
            Console.Clear();
            Console.WriteLine("Would you like to resume playing? Y/N");

            if ((keyInfo = Console.ReadKey(true)).Key == ConsoleKey.N)
            {
                Console.Clear();
                GameOver();//End game
            }

            Console.Clear();
        }

        public static void GameOver()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(@"
  ________                      ________                     
 /  _____/_____    _____   ____ \_____  \___  __ ___________ 
/   \  ___\__  \  /     \_/ __ \ /   |   \  \/ // __ \_  __ \
\    \_\  \/ __ \|  Y Y  \  ___//    |    \   /\  ___/|  | \/
 \______  (____  /__|_|  /\___  >_______  /\_/  \___  >__|   
        \/     \/      \/     \/        \/          \/       








");

            Console.WriteLine("Would you like to try again? Y/N");
            if ((keyInfo = Console.ReadKey(true)).Key == ConsoleKey.Y)
            {
                Console.Clear();

                Main();//Restarts the game
            }
            else if ((keyInfo = Console.ReadKey(true)).Key == ConsoleKey.N)
            {
                Environment.Exit(-1);
            }
        }

    }//end of class  
}