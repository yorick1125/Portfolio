﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;


namespace gametester
{
    public class Mob
    {
        //Mob
        public static int xpos, ypos, count = 1;
        public static string icon = "0", deletemob = " ";
        public static bool alive = true;
        public static bool bulletc = false;
        public static int mhealth = 100;
        public static DateTime previousmobmove = DateTime.Now;
        public static TimeSpan mobspeed = new TimeSpan(0, 0, 0, 0, 80);
        public static Mob[] totalmobs = new Mob[100];

        

        //xpos[i]
        //ypos[i]

    }

    class Bullet
    {
        //Bullets
        public int xpos, ypos;
        public int bdirection;
        public bool moving = false;
        public static string bulletchar = "*";
        public static List<Bullet> bulletlist = new List<Bullet>();
        public DateTime previousbullet = DateTime.Now;
        public TimeSpan bulletspeed = new TimeSpan(0, 0, 0, 0, 5);

        public Bullet(int dxpos, int dypos, int ddirection)
        {
            xpos = dxpos;
            ypos = dypos;
            bdirection = ddirection;
            moving = true;

            previousbullet = DateTime.Now;
            bulletspeed = new TimeSpan(0, 0, 0, 0, 10);
        }
    }

    class Program
    {
        //Constants
        public const int buffersize_x = 120;
        public const int buffersize_y = 30;
        public const int windowsize_x = 120;
        public const int windowsize_y = 30;
        public const int windowcenter_x = windowsize_x / 2;
        public const int windowcenter_y = windowsize_y / 2;
        public const int screenmin = 0;
        public const int statliney = 5;

        //Global variables

        //Player
        public static int playerx = windowcenter_x;
        public static int playery;
        public static string deletep = " ";
        public static int direction = 1;
        public static DateTime previousplayermove = DateTime.Now;
        public static TimeSpan playerspeed = new TimeSpan(0, 0, 0, 0, 80);

        //Player 2
        public static int p2x;
        public static int p2y;


        //Food
        public static int foodx;
        public static int foody;

        //Stats1
        public static int gamespeed, score = 0, health;
        public static int statsx = 0;
        public static int statsy = 4;

        //Other
        public static string playerchar = " X ", foodchar = "@";
        public static ConsoleKeyInfo keyInfo;
        public static bool gameover = false;
        public static bool win = false;
        public static Random rnd = new Random();
        public static int interval = 5;
        public static bool automatic = false;
        public static bool multi = false;

        public static void Main()
        {
            /*
            System.Media.SoundPlayer player = new System.Media.SoundPlayer();
            player.SoundLocation = @"C:\Users\Yoric\Desktop\Music\Songs\Futsal_Shuffle.wav";
            player.Load();
            player.Play();
            */

            Mob.mobspeed = new TimeSpan(0, 0, 0, 0, 80);
            Menu();
            
            //Variables
            playery = windowcenter_y;//15
            gameover = false;

            //display size and cursor position at the beginning
            Console.SetWindowSize(windowsize_x, windowsize_y);
            Console.SetBufferSize(buffersize_x, buffersize_y);
            Console.SetCursorPosition(windowcenter_x, windowcenter_y);
            playerx = windowcenter_x;
            playery = windowcenter_y;
            p2x = windowcenter_x;
            p2y = windowcenter_y;
            Console.CursorVisible = false;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write(playerchar);
            Console.ForegroundColor = ConsoleColor.White;
            gamespeed = 1;
            health = 1000;
            score = 0;

            //Spawn Objects
            Console.ForegroundColor = ConsoleColor.Green;
            Spawn(foodx, foody, foodchar);
            Console.ForegroundColor = ConsoleColor.Blue;
            Spawn(Mob.xpos, Mob.ypos, Mob.icon);
            Console.ForegroundColor = ConsoleColor.White;

            
            while (!gameover && !automatic && !multi)
            {
                Stats();
                MovePlayer();//player mouvement with keyboard
                MoveBullet();
                Movemob();
            }

            while (!gameover && automatic && !multi)
            {
                Stats();
                Automation();
                MoveBullet();
                Movemob();
            }

            while (!gameover && !automatic && multi)
            {
                Stats();
                MovePlayer();//player mouvement with keyboard
                Automation();
                MoveBullet();
                Movemob();
            }

            if (gameover)
            {
                GameOver();
            }
            Console.ReadKey();
            Console.ReadKey();
        }//end of main

        public static void Menu()
        {
 

            Console.SetCursorPosition(windowcenter_x, 2);
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write(@"
            .___                                   ._____.   .__             ________                       
            |   | _____ ______   ____  ______ _____|__\_ |__ |  |   ____    /  _____/_____    _____   ____  
            |   |/     \\____ \ /  _ \/  ___//  ___/  || __ \|  | _/ __ \  /   \  ___\__  \  /     \_/ __ \ 
            |   |  Y Y  \  |_> >  <_> )___ \ \___ \|  || \_\ \  |_\  ___/  \    \_\  \/ __ \|  Y Y  \  ___/ 
            |___|__|_|  /   __/ \____/____  >____  >__||___  /____/\___  >  \______  (____  /__|_|  /\___  >
                      \/|__|              \/     \/        \/          \/          \/     \/      \/     \/ 
                                                                                                
                                                                                                
                                                                                                
                                                                                                
                                                                                                
                                                                                                

");
            Console.ForegroundColor = ConsoleColor.White;


            string t = "The goal of the game is to get 100 points by hovering your player" + playerchar + "on to the " + foodchar + " for 100 points each time. ";
            Console.SetCursorPosition((Console.WindowWidth - t.Length) / 2, Console.CursorTop);
            Console.WriteLine(t);

            string a = "But beware of enemy " + Mob.icon + "s that will come attacking. Defend yourself by shooting bullets at them. ";
            Console.SetCursorPosition((Console.WindowWidth - a.Length) / 2, Console.CursorTop);
            Console.WriteLine(a);

            string u = "Press any key to begin playing. If you want to see the game play automatically press A. ";
            Console.SetCursorPosition((Console.WindowWidth - u.Length) / 2, Console.CursorTop);
            Console.WriteLine(u);

            string s = "                                           ";
            Console.WriteLine(" ");
            Console.WriteLine(s + "W = Up");
            Console.WriteLine(s + "S = Down");
            Console.WriteLine(s + "A = Left");
            Console.WriteLine(s + "D = Right");
            Console.WriteLine(s + "Spacebar = Shoot");
            Console.WriteLine(s + "Escape = Pause");
            Console.WriteLine(s + "DO NOT CHANGE THE WINDOW SIZE");
            keyInfo = Console.ReadKey(true);
            keyInfo = Console.ReadKey(true);

            if (keyInfo.Key == ConsoleKey.A)
            {
                automatic = true;
            }
            if (keyInfo.Key == ConsoleKey.M)
            {
                multi = true;
            }


            Console.Clear();
        }

        public static void Spawn(int xpos, int ypos, string icon)
        {
            //spawn in random location
            xpos = rnd.Next(2, windowsize_x);
            ypos = rnd.Next(statliney + 1, windowsize_y - 1);
            Console.SetCursorPosition(xpos, ypos);
            Console.Write(icon);
            Console.ForegroundColor = ConsoleColor.White;

            if (Mob.icon == icon)
            {
                Mob.xpos = xpos;
                Mob.ypos = ypos;
            }
            else
            {
                foodx = xpos;
                foody = ypos;
            }
        }

        public static void MovePlayer()
        {
            bool yes = true;
            if ((Console.KeyAvailable))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                keyInfo = Console.ReadKey(true);
                switch (keyInfo.Key)
                {
                    //Mouvement
                    //Up
                    case ConsoleKey.W:
                        Console.SetCursorPosition(playerx + 1, playery);
                        Console.Write(" ");//Erases previous player character
                        direction = 1;
                        if (multi == true)
                        {
                            p2y--;
                            p2x++;
                        }
                        else
                        {
                            playery--;
                        }
                        OffScreenP();//Preventing player from going off the screen
                        break;
                    //Down
                    case ConsoleKey.S:
                        Console.SetCursorPosition(playerx + 1, playery);
                        Console.Write(" ");//Erases previous player character
                        direction = 2;
                        if (multi == true)
                        {
                            p2y++;
                            p2x++;

                        }
                        else
                        {
                            playery++;
                        }
                        OffScreenP();//Preventing player from going off the screen
                        break;
                    //Left
                    case ConsoleKey.A:
                        Console.SetCursorPosition(playerx, playery);
                        Console.Write(" ");//Erases previous player character
                        direction = 3;
                        if (multi == true)
                        {
                            p2x--;
                        }
                        else
                        {
                            playerx--;
                        }
                        OffScreenP();//Preventing player from going off the screen
                        break;
                    //Right
                    case ConsoleKey.D:
                        Console.SetCursorPosition(playerx, playery);
                        Console.Write(" ");//Erases previous player character
                        direction = 4;
                        if (multi == true)
                        {
                            p2x++;
                        }
                        else
                        {
                            playerx++;
                        }
                        OffScreenP();//Preventing player from going off the screen
                        break;
                    //Shoot
                    case ConsoleKey.Spacebar:
                        break;
                    //Pause Menu
                    case ConsoleKey.Escape:
                        PauseMenu();
                        if (multi == true)
                        {
                            Console.SetCursorPosition(p2x, p2y);
                            Console.Write(playerchar);
                            Console.SetCursorPosition(p2x, p2y);
                        }
                        else
                        {
                            Console.SetCursorPosition(playerx, playery);
                            Console.Write(playerchar);
                            Console.SetCursorPosition(playerx, playery);
                        }
                        break;
                }//end of switch

                if (keyInfo.Key == ConsoleKey.Spacebar)//Shoot
                {
                    ShootBullet();

                }
                if (multi == true)
                {
                    Console.SetCursorPosition(p2x, p2y);//Sets to the new position
                }
                else
                {
                    Console.SetCursorPosition(playerx, playery);//Sets to the new position
                }
                Console.Write(playerchar);//Draw PLayer
                

                if ((playerx == foodx - 1 && playery == foody) || (p2x == foodx - 1 && p2y == foody && multi == true))//player eats food
                {
                    //whenever player eats food a new one spawns
                    Console.ForegroundColor = ConsoleColor.Green;
                    Spawn(foodx, foody, foodchar);
                    Console.ForegroundColor = ConsoleColor.White;
                    score += 10;
                    gamespeed++;
                    Mob.mobspeed = new TimeSpan(0, 0, 0, 0, 80 - score);
                }
            

            }//end of Console.ReadKey if statement
            
        }

        public static void Automation()
        {
            int random;
            bool closetomob = Closetomob();

            if (closetomob == false)
            {
                if (playerx == foodx && playery < foody)
                {
                    direction = 2;
                }//player is directly above food

                else if (playerx == foodx && playery > foody)
                {
                    direction = 1;
                }//player is directly below the food

                else if (playery == foody && playerx > foodx)
                {
                    direction = 3;
                }//player is directly to the right of the food

                else if (playery == foody && playerx < foodx)
                {
                    direction = 4;
                }//player is directly to the left of the food

                else if (playery < foody && playerx > foodx)
                {
                    random = rnd.Next(1, 2);
                    if (random == 1)
                    {
                        direction = 2;//down
                    }
                    else if (random == 2)
                    {
                        direction = 3;//left
                    }

                }//player is up/right to the food

                else if (playery > foody && playerx > foodx)
                {
                    random = rnd.Next(1, 2);
                    if (random == 1)
                    {
                        direction = 1;//up
                    }
                    else if (random == 2)
                    {
                        direction = 3;//left
                    }
                }//player is down/right to the food

                else if (playery < foody && playerx < foodx)
                {
                    random = rnd.Next(1, 2);
                    if (random == 1)
                    {
                        direction = 2;//up
                    }
                    else if (random == 2)
                    {
                        direction = 3;//right
                    }

                }//player is up/left to the food

                else if (playery > foody && playerx < foodx)
                {
                    random = rnd.Next(1, 2);
                    if (random == 1)
                    {
                        direction = 1;//up
                    }
                    else if (random == 2)
                    {
                        direction = 4;//right
                    }

                }//player is down/left to the food

            }

            else if (closetomob == true)

            {
                if (playerx == Mob.xpos && playery < Mob.ypos)
                {
                    direction = 2;
                }//player is directly above mob

                else if (playerx == Mob.xpos && playery > Mob.ypos)
                {
                    direction = 1;
                }//player is directly below the mob

                else if (playery == Mob.ypos && playerx > Mob.xpos)
                {
                    direction = 3;
                }//player is directly to the right of the mob

                else if (playery == Mob.ypos && playerx < Mob.xpos)
                {
                    direction = 4;
                }//player is directly to the left of the mob
            }


            if ((DateTime.Now - previousplayermove) >= playerspeed)
            {
                previousplayermove = DateTime.Now;
                Console.ForegroundColor = ConsoleColor.Red;
                switch (direction)
                {
                    //Mouvement
                    //Up
                    case 1:
                        Console.SetCursorPosition(playerx + 1, playery);
                        Console.Write(" ");//Erases previous player character
                        direction = 1;
                        playery--;
                        OffScreenP();//Preventing player from going off the screen
                        break;
                    //Down
                    case 2:
                        Console.SetCursorPosition(playerx + 1, playery);
                        Console.Write(" ");//Erases previous player character
                        direction = 2;
                        playery++;
                        OffScreenP();//Preventing player from going off the screen
                        break;
                    //Left
                    case 3:
                        Console.SetCursorPosition(playerx, playery);
                        Console.Write(" ");//Erases previous player character
                        direction = 3;
                        playerx--;
                        OffScreenP();//Preventing player from going off the screen
                        break;
                    //Right
                    case 4:
                        Console.SetCursorPosition(playerx, playery);
                        Console.Write(" ");//Erases previous player character
                        direction = 4;
                        playerx++;
                        OffScreenP();//Preventing player from going off the screen
                        break;
              
                }//end of switch

                if (closetomob == true)//Shoot
                {
                    ShootBullet();
                    closetomob = false;

                }
                Console.SetCursorPosition(playerx, playery);//Sets to the new position
                Console.Write(playerchar);//Draw PLayer

                if (playerx == foodx - 1 && playery == foody)//player eats food
                {
                    //whenever player eats food a new one spawns
                    Console.ForegroundColor = ConsoleColor.Green;
                    Spawn(foodx, foody, foodchar);
                    Console.ForegroundColor = ConsoleColor.White;
                    score += 10;
                    gamespeed++;
                    Mob.mobspeed = new TimeSpan(0, 0, 0, 0, 80 - score);
                    playerspeed = new TimeSpan(0, 0, 0, 0, 80 - score);


                }
            }//end of Console.ReadKey if statement


        }
        
        public static bool Closetomob()
        {
            bool closetomob = false;
            int xdistance = Mob.xpos - playerx;//horizontal distance between mob and player
            int ydistance = Mob.ypos - playery;//vertical distance between mob and player

            //if result is in negat ive number than convert to positive
            if (xdistance < 0)
            {
                xdistance *= -1;
            }
            if (ydistance < 0)
            {
                ydistance *= -1;
            }

            //if distance is shorter than 40: shoots bullet at mob
            if (xdistance <= 40 && ydistance <= 40)
            {
                closetomob = true;
            }
            return closetomob;
        }

        public static void Movemob()
        {
            //Variables
            int direction = 1;
            bool bulletc = false;
            bulletc = BulletCollision();
            PlayerCollision();
            int random;
            Random rnd = new Random(Guid.NewGuid().GetHashCode());

            if (Mob.alive == true)
            {
                if (playerx == Mob.xpos && playery < Mob.ypos)
                {
                    direction = 1;
                }//player is directly above mob

                else if (playerx == Mob.xpos && playery > Mob.ypos)
                {
                    direction = 2;
                }//player is directly below the mob

                else if (playery == Mob.ypos && playerx > Mob.xpos)
                {
                    direction = 4;
                }//player is directly to the right of the mob

                else if (playery == Mob.ypos && playerx < Mob.xpos)
                {
                    direction = 3;
                }//player is directly to the left of the mob

                else if (playery < Mob.ypos && playerx > Mob.xpos)
                {
                    random = rnd.Next(1, 2);
                    if (random == 1)
                    {
                        direction = 1;//up
                    }
                    else if (random == 2)
                    {
                        direction = 4;//right
                    }

                }//player is up/right to the mob

                else if (playery > Mob.ypos && playerx > Mob.xpos)
                {
                    random = rnd.Next(1, 2);
                    if (random == 1)
                    {
                        direction = 2;//down
                    }
                    else if (random == 2)
                    {
                        direction = 4;//right
                    }
                }//player is down/right to the mob

                else if (playery < Mob.ypos && playerx < Mob.xpos)
                {
                    random = rnd.Next(1, 2);
                    if (random == 1)
                    {
                        direction = 1;//down
                    }
                    else if (random == 2)
                    {
                        direction = 3;//left
                    }

                }//player is up/left

                else if (playery > Mob.ypos && playerx < Mob.xpos)
                {

                    random = rnd.Next(1, 2);
                    if (random == 1)
                    {
                        direction = 2;//down
                    }
                    else if (random == 2)
                    {
                        direction = 3;//left
                    }

                }//player is down/left

            }


            Console.ForegroundColor = ConsoleColor.Blue;

            if ((DateTime.Now - Mob.previousmobmove) >= Mob.mobspeed && Mob.alive == true && bulletc == false)
            {
                for (int i = 0; i < 1; i++)
                {
                        Mob.previousmobmove = DateTime.Now;
                        switch (direction)
                        {
                            //Mouvement
                            case 1://Up
                                Console.SetCursorPosition(Mob.xpos, Mob.ypos);
                                Mob.ypos -= 1;
                                //Preventing mob from going off the screen
                                OffScreenM();
                                Console.Write(Mob.deletemob);
                                Console.SetCursorPosition(Mob.xpos, Mob.ypos);
                                break;
                            case 2://Down
                                Console.SetCursorPosition(Mob.xpos, Mob.ypos);
                                Mob.ypos += 1;
                                //Preventing mob from going off the screen
                                OffScreenM();
                                Console.Write(Mob.deletemob);
                                Console.SetCursorPosition(Mob.xpos, Mob.ypos);
                                break;
                            case 3://Left
                                Console.SetCursorPosition(Mob.xpos, Mob.ypos);
                                Mob.xpos -= 1;
                                //Preventing mob from going off the screen
                                OffScreenM();
                                Console.Write(Mob.deletemob);
                                Console.SetCursorPosition(Mob.xpos, Mob.ypos);
                                break;
                            case 4://Right
                                Console.SetCursorPosition(Mob.xpos, Mob.ypos);
                                Mob.xpos += 1;
                                //Preventing mob from going off the screen
                                OffScreenM();
                                Console.Write(Mob.deletemob);
                                Console.SetCursorPosition(Mob.xpos, Mob.ypos);
                                break;
                        }
                        //Draw
                        Console.Write(Mob.icon);
                }
            }

            bulletc = BulletCollision();
            Console.ForegroundColor = ConsoleColor.White;
        }

        public static void ShootBullet()
        {
            switch (direction)
            {
                case 1://up
                    Bullet.bulletlist.Add(new Bullet(playerx + 1, playery - 1, direction));
                    break;
                case 2://down
                    Bullet.bulletlist.Add(new Bullet(playerx + 1, playery + 1, direction));
                    break;
                case 3://left
                    Bullet.bulletlist.Add(new Bullet(playerx - 1, playery, direction));
                    break;
                case 4://right
                    Bullet.bulletlist.Add(new Bullet(playerx + 2, playery, direction));
                    break;
            }
        }

        public static void MoveBullet()
        {
            for (int i = 0; i < Bullet.bulletlist.Count; i++)
            {
                if ((DateTime.Now - Bullet.bulletlist[i].previousbullet) >= Bullet.bulletlist[i].bulletspeed && Bullet.bulletlist[i].moving == true)
                {
                    Console.SetCursorPosition(Bullet.bulletlist[i].xpos, Bullet.bulletlist[i].ypos);
                    Console.Write(" ");
                    Bullet.bulletlist[i].previousbullet = DateTime.Now;
                    switch (Bullet.bulletlist[i].bdirection)
                    {
                        case 1:
                            Bullet.bulletlist[i].ypos -= 1;
                            OffScreenB();
                            break;
                        case 2:
                            Bullet.bulletlist[i].ypos += 1;
                            OffScreenB();
                            break;
                        case 3:
                            Bullet.bulletlist[i].xpos -= 1;
                            OffScreenB();
                            break;
                        case 4:
                            Bullet.bulletlist[i].xpos += 1;
                            OffScreenB();
                            break;
                    }
                    if (Bullet.bulletlist[i].moving == true)
                    {
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.SetCursorPosition(Bullet.bulletlist[i].xpos, Bullet.bulletlist[i].ypos);
                        Console.Write(Bullet.bulletchar);
                    }
                }//end of DateTime if statement
            }//end of bulletlist for loop
        }

        public static bool BulletCollision()
        {
            bool bulletc = false;
            for (int i = 0; i < Bullet.bulletlist.Count; i++)
            {
                if (Bullet.bulletlist[i].xpos == Mob.xpos && Bullet.bulletlist[i].ypos == Mob.ypos)
                {
                    Bullet.bulletlist[i].moving = false;
                    Bullet.bulletlist[i].xpos = 0;
                    Bullet.bulletlist[i].ypos = 0;
                    bulletc = true;
                    Console.SetCursorPosition(Mob.xpos, Mob.ypos);
                    Console.Write(Mob.deletemob);//Deletes mob
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Spawn(Mob.xpos, Mob.ypos, Mob.icon);
                }
            }
            return bulletc;
        }

        public static void PlayerCollision()
        {
            if (Mob.xpos == playerx && Mob.ypos == playery)
            {
                health -= 10;
                Console.SetCursorPosition(Mob.xpos, Mob.ypos);
                Console.Write(Mob.deletemob);//Deletes mob
                Console.ForegroundColor = ConsoleColor.Red;
                Console.SetCursorPosition(playerx, playery);
                Console.Write(playerchar);
                Console.ForegroundColor = ConsoleColor.Blue;
                Spawn(Mob.xpos, Mob.ypos, Mob.icon);
            }
        }

        public static void OffScreenP()
        {
            //Right
            if (playerx >= buffersize_x - 1)
            {
                playerx--;
            }
            //Left
            if (playerx <= screenmin)
            {
                playerx++;
            }
            //Down
            if (playery >= buffersize_y - 1)
            {
                playery--;
            }
            //Up
            if (playery < statliney)
            {
                playery++;
            }
        }

        public static void OffScreenM()
        {
            //Right
            if (Mob.xpos >= buffersize_x - 1)
            {
                Mob.xpos -= 2;
            }
            //Left
            if (Mob.xpos <= screenmin)
            {
                Mob.xpos += 2;
            }
            //Down
            if (Mob.ypos >= buffersize_y)
            {
                Mob.ypos -= 2;
            }
            //Up
            if (Mob.ypos < statliney)
            {
                Mob.ypos += 2;
            }

        }

        public static void OffScreenB()
        {
            for (int i = 0; i < Bullet.bulletlist.Count; i++)
            {
                //Right
                if (Bullet.bulletlist[i].xpos >= buffersize_x - 1)
                {
                    Bullet.bulletlist[i].xpos -= 1;
                    Console.SetCursorPosition(Bullet.bulletlist[i].xpos, Bullet.bulletlist[i].ypos);
                    Console.Write(" ");
                    Bullet.bulletlist[i].moving = false;
                }
                //Left
                if (Bullet.bulletlist[i].xpos <= screenmin)
                {
                    Bullet.bulletlist[i].xpos += 1;
                    Console.SetCursorPosition(Bullet.bulletlist[i].xpos, Bullet.bulletlist[i].ypos);
                    Console.Write(" ");
                    Bullet.bulletlist[i].moving = false;
                }
                //Down
                if (Bullet.bulletlist[i].ypos >= buffersize_y)
                {
                    Bullet.bulletlist[i].ypos -= 1;
                    Console.SetCursorPosition(Bullet.bulletlist[i].xpos, Bullet.bulletlist[i].ypos);
                    Console.Write(" ");
                    Bullet.bulletlist[i].moving = false;
                }
                //Up
                if (Bullet.bulletlist[i].ypos < statliney)
                {
                    Bullet.bulletlist[i].ypos += 1;
                    Console.SetCursorPosition(Bullet.bulletlist[i].xpos, Bullet.bulletlist[i].ypos);
                    Console.Write(" ");
                    Bullet.bulletlist[i].moving = false;
                }
            }
        }

        public static void Stats()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.SetCursorPosition(statsx, statsy);

            for (int i = 0; i < windowsize_x; i++)
            {
                Console.Write("_");
            }

            statsy -= 3;
            Console.SetCursorPosition(statsx, statsy);
            Console.WriteLine("Health: " + health + " ");
            Console.WriteLine("Score: " + score);
            Console.WriteLine("Gamespeed: " + gamespeed);
            Console.ForegroundColor = ConsoleColor.White;
            statsy = 4;

            Console.ForegroundColor = ConsoleColor.Green;
            Console.SetCursorPosition(foodx, foody);
            Console.Write(foodchar);
            Console.ForegroundColor = ConsoleColor.White;
            Console.SetCursorPosition(playerx, playery);

            if (score >= 1000)
            {
                score = 100;
                gameover = false;
                GameOver();

            }
            if (health <= 0)//player loses
            {
                health = 0;
                gameover = true;
                GameOver();
            }
           
            for (int i = 0; i < Bullet.bulletlist.Count; i++)
            {
                if (Bullet.bulletlist[i].moving == false)
                {
                    Bullet.bulletlist.RemoveAt(i);
                }

            }
            
        }

        public static void PauseMenu()
        {
            Console.Clear();
            Console.WriteLine("Would you like to resume playing? Y/N");

            if ((keyInfo = Console.ReadKey(true)).Key == ConsoleKey.N)
            {
                Console.Clear();
                GameOver();//End game
            }

            Console.Clear();
        }

        public static void GameOver()
        {
            Console.Clear();
            automatic = false;
            for (int i = 0; i < Bullet.bulletlist.Count; i++)
            {
                Bullet.bulletlist[i].moving = false;
            }
            if (gameover == true)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(@"
                                ________                      ________                     
                                /  _____/_____    _____   ____ \_____  \___  __ ___________ 
                                /   \  ___\__  \  /     \_/ __ \ /   |   \  \/ // __ \_  __ \
                                \    \_\  \/ __ \|  Y Y  \  ___//    |    \   /\  ___/|  | \/
                                \______  (____  /__|_|  /\___  >_______  /\_/  \___  >__|   
                                        \/     \/      \/     \/        \/          \/       
");
            }

            else if (gameover == false)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine(@"
                    _________                                     __        .__          __  .__                      
                    \_   ___ \  ____   ____    ________________ _/  |_ __ __|  | _____ _/  |_|__| ____   ____   ______
                    /    \  \/ /  _ \ /    \  / ___\_  __ \__  \\   __\  |  \  | \__  \\   __\  |/  _ \ /    \ /  ___/
                    \     \___(  <_> )   |  \/ /_/  >  | \// __ \|  | |  |  /  |__/ __ \|  | |  (  <_> )   |  \\___ \ 
                     \______  /\____/|___|  /\___  /|__|  (____  /__| |____/|____(____  /__| |__|\____/|___|  /____  >
                            \/            \//_____/            \/                     \/                    \/     \/ 



");
            }
            string v = "Score: " + score;
            Console.SetCursorPosition((Console.WindowWidth - v.Length) / 2, Console.CursorTop);
            Console.WriteLine(v);

            string w = "Would you like to try again? Y/N";
            Console.SetCursorPosition((Console.WindowWidth - w.Length) / 2, Console.CursorTop);
            Console.WriteLine(w);

            if ((keyInfo = Console.ReadKey(true)).Key == ConsoleKey.Y)
            {
                Console.Clear();
                gameover = false;
                Main();//Restarts the game
            }
            else if ((keyInfo = Console.ReadKey(true)).Key == ConsoleKey.N)
            {
                Environment.Exit(-1);
            }
            else
            {
                GameOver();
            }

        }

    }//end of class  
}






