Instructions: 
1. Open the application exe file. DO NOT TOUCH OR MOVE youtube-dl.exe
2. Enter the url of the youtube link you would like to download.
3. Click download.
4. Should the download be successful, the video will appear in the youtubedl folder. 
5. Enjoy! Copy or move the video wherever you would like.